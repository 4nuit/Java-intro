/**
 * Package contenant les différentes figures géométriques
 */
package figures;

